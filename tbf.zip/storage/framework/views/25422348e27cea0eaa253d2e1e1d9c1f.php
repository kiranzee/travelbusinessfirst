<div id="exploreCarousel" class="owl-carousel owl-theme">
    <?php if($exploredestination->isNotEmpty()): ?>
        <?php $__currentLoopData = $exploredestination; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $explore): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
                <a href="javascript:void(0)" class="card explore-card">
                    <div class="card-img-outer">
                        <img src="<?php echo e(asset('uploads/' . $explore->image)); ?>" class="img-fluid"
                            alt="<?php echo e($explore->image_seo); ?>">
                        <h1 class="explore-head"><?php echo e($explore->title); ?></h1>
                        <div class="explore-text">
                            <small class="">Starting from</small>
                            <h4 class="fw-bold m-0">£<?php echo e(number_format($explore->price, 0)); ?></h4>
                        </div>
                        <div class="overlay-top"></div>
                    </div>
                    <div class="card-design-1"></div>
                    <div class="card-design-2"></div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>No Explore destinations available at the moment.</p>
    <?php endif; ?>
</div>
<?php /**PATH C:\Projects\New - Travelbusinessfirst\tbf\resources\views/layouts/exploredestination.blade.php ENDPATH**/ ?>