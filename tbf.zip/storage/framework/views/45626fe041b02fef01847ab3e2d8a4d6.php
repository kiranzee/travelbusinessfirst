
<?php $__env->startSection('title', 'Most Popular Flight Destinations'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Hero Section Banner</h2>

        <!-- Display success message -->
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <!-- Add new destination button -->
        <div class="mb-3">
            <a href="<?php echo e(route('hero.create')); ?>" class="btn btn-primary">Add Hero Section Banner</a>
        </div>

        <!-- Destination table -->
        <table class="table table-bordered">
            <thead>
                <tr>

                    <th>ID</th>

                    <th>Heading</th>
                    <th>Title</th>
                    <th>Short Description</th>
                    <th>Image</th>
                    <th>status</th>
                    <th>Action</th>

                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $herosection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $herosection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($herosection->id); ?></td>
                        <td><?php echo e($herosection->heading); ?></td>
                        <td><?php echo e($herosection->title); ?></td>
                        <td><?php echo e($herosection->description); ?></td>
                        <td><img src="<?php echo e(asset('uploads/' . $herosection->image)); ?>" alt="<?php echo e($herosection->title); ?>"
                                class="img-fluid" style="max-width: 100%; height: auto;" /></td>
                        <td><?php echo e($herosection->status); ?></td>
                        <td>
                            <!-- Edit button -->
                            <a href="<?php echo e(route('herosection.edit', $herosection->id)); ?>"
                                class="btn btn-sm btn-warning">Edit</a>

                            <!-- Delete button -->
                            <form action="<?php echo e(route('herosection.destroy', $herosection->id)); ?>" method="POST"
                                style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger"
                                    onclick="return confirm('Are you sure you want to delete this destination?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\New - Travelbusinessfirst\tbf\resources\views/layouts/hero/index.blade.php ENDPATH**/ ?>