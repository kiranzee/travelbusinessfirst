<div id="partnerCarousel" class="owl-carousel owl-theme">
    <?php if($flightpartner->isNotEmpty()): ?>
        <?php $__currentLoopData = $flightpartner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item"><img class="img-fluid" src="<?php echo e(asset('uploads/partners/' . $partner->image)); ?>"
                    alt=""></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>No Explore destinations available at the moment.</p>
    <?php endif; ?>

</div>
<?php /**PATH C:\Projects\New - Travelbusinessfirst\tbf\resources\views/layouts/flightpartner.blade.php ENDPATH**/ ?>