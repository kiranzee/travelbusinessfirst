
<?php $__env->startSection('title', 'Ticket Enquiry'); ?>
<?php $__env->startSection('content'); ?>
    <?php
        use Carbon\Carbon;
    ?>
    <div class="container">
        <h2>Ticket Enquiry</h2>

        <!-- Display success message -->
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>


        <!-- Destination table -->
        <table class="table table-bordered w-100">
            <thead>
                <tr>

                    <th>ID</th>

                    <th>Flight ID</th>
                    <th>Customer Name</th>
                    <th>Customer Email</th>
                    <th>Customer Phone</th>
                    <th>Source</th>
                    <th>Destination</th>
                    <th>Departure Date</th>
                    <th>Return Date</th>
                    <th>Passenger(s)</th>
                    <th>Class Type</th>
                    <th>Create Date</th>


                </tr>
            </thead>
            <tbody>
                <?php if($ticket->isNotEmpty()): ?>
                    <?php $__currentLoopData = $ticket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($ticket->id); ?></td>
                            <td><?php echo e($ticket->flight_id); ?></td>
                            <td><?php echo e($ticket->customer_name); ?></td>
                            <td><a href="mailto:<?php echo e($ticket->customer_email); ?>"><?php echo e($ticket->customer_email); ?></td>
                            <td><a href="tel:+44<?php echo e($ticket->customer_phone); ?>"><?php echo e($ticket->customer_phone); ?></a></td>

                            <td><?php echo e($ticket->source); ?></td>
                            <td><?php echo e($ticket->destination); ?></td>
                            <td><?php echo e(Carbon::parse($ticket->departure_date)->format('D, d M y')); ?></td>
                            <td><?php echo e(Carbon::parse($ticket->return_date)->format('D, d M y')); ?></td>
                            <td><?php echo e($ticket->passengers); ?></td>
                            <td>
                                <?php if($ticket->class_type == '1'): ?>
                                    Economy Class
                                <?php elseif($ticket->class_type == '2'): ?>
                                    Business Class
                                <?php elseif($ticket->class_type == '3'): ?>
                                    First Class
                                <?php elseif($ticket->class_type == '4'): ?>
                                    Premium Economy
                                <?php endif; ?>
                            </td>
                            <td><?php echo e(Carbon::parse($ticket->created_at)->format('D, d M y')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7">
                            <p>No Ticket Enquiries available at the moment.</p>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\New - Travelbusinessfirst\tbf\resources\views/layouts/customerenquiry/ticketenquiry.blade.php ENDPATH**/ ?>