<div id="mainCarousel" class="owl-carousel owl-theme">
    <?php if($herosection->isNotEmpty()): ?>
    <?php $__currentLoopData = $herosection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <div class="item">
        <div class="main-slider">
            <span class="overlay-left"></span>
            <img src="<?php echo e(asset('uploads/' . $hero->image)); ?>" alt="<?php echo e($hero->title); ?>" class="img-fluid">
            <div class="top-content">
                <div class="container">
                    <h5 class="fs-3 text-white fw-normal"><?php echo e($hero->heading); ?></h5>
                    <h2 class="fs-1 fw-bold text-white"><?php echo e($hero->title); ?></h2>
                    <p class="fs-4 text-white"><?php echo $hero->description; ?>

                       
                    </p>
                </div>
            </div>
        </div>
    </div>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>No popular destinations available at the moment.</p>
    <?php endif; ?>
</div><?php /**PATH C:\Projects\New - Travelbusinessfirst\tbf\resources\views/layouts/herosection.blade.php ENDPATH**/ ?>