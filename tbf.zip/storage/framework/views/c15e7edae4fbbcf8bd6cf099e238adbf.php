
<?php $__env->startSection('title', 'Hotel Enquiry'); ?>
<?php $__env->startSection('content'); ?>
    <?php
        use Carbon\Carbon;
    ?>
    <div class="container">
        <h2>Hotel Enquiry</h2>

        <!-- Display success message -->
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>


        <!-- Destination table -->
        <table class="table table-bordered w-100">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Customer Name</th>
                    <th>Customer Email</th>
                    <th>Customer Phone</th>
                    <th>Destination</th>
                    <th>Check In Date</th>
                    <th>Check Out Date</th>
                    <th>Details</th>
                </tr>
            </thead>
            <tbody>
                <?php if($hotelEnquiry->isNotEmpty()): ?>
                    <?php $__currentLoopData = $hotelEnquiry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($hotel->id); ?></td>
                            <td><?php echo e($hotel->customer_name); ?></td>
                            <td><a href="mailto:<?php echo e($hotel->customer_email); ?>"><?php echo e($hotel->customer_email); ?></a></td>
                            <td><a href="tel:+44<?php echo e($hotel->customer_phone); ?>"><?php echo e($hotel->customer_phone); ?></a></td>
                            <td><?php echo e($hotel->destination); ?></td>
                            <td><?php echo e(Carbon::parse($hotel->checkin)->format('D, d M y')); ?></td>
                            <td><?php echo e(Carbon::parse($hotel->checkout)->format('D, d M y')); ?></td>
                            <td>
                                <button class="btn btn-sm btn-primary toggle-details" data-ticket-id="<?php echo e($hotel->id); ?>">
                                    Show Details
                                </button>
                            </td>
                        </tr>
                        <tr class="details-row" id="details-<?php echo e($hotel->id); ?>" style="display: none;">
                            <td colspan="8">
                                <table border="1" cellpadding="10" cellspacing="0"
                                    style="width: 100%; border-collapse: collapse;">
                                    <thead>
                                        <tr>
                                            <th>No.of Nights</th>
                                            <th>Hotel Rating</th>
                                            <th>Room Type</th>
                                            <th>Adult Count</th>
                                            <th>Child Count</th>
                                            <th>Infant Count</th>
                                            <th>No.of Rooms</th>
                                            <th>Comments</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <tr>
                                            <td><?php echo e($hotel->noofnightstay); ?></td>
                                            <td><?php echo e($hotel->starhotel); ?></td>
                                            <td><?php echo e($hotel->Roomtype); ?></td>
                                            <td><?php echo e($hotel->adultcount); ?></td>
                                            <td><?php echo e($hotel->childcount); ?></td>
                                            <td><?php echo e($hotel->infantcount); ?></td>
                                            <td><?php echo e($hotel->noofrooms); ?></td>
                                            <td><?php echo e($hotel->customer_comments); ?></td>
                                        </tr>

                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7">
                            <p>No City Flight Enquiries available at the moment.</p>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>




    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\New - Travelbusinessfirst\tbf\resources\views/layouts/customerenquiry/hotel.blade.php ENDPATH**/ ?>