<div class="tab-pane fade show active" id="cityFlight" role="tabpanel" aria-labelledby="cityFlight-tab">
    <div class="row">
        <?php if($popularDestinations->isNotEmpty()): ?>
            <?php $__currentLoopData = $popularDestinations->chunk(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunkedDestinations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-6 col-md-3">
                    <?php $__currentLoopData = $chunkedDestinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(url('/flight-city-search/' . $destination->title . '/' . $destination->id)); ?>">Flights
                            to <?php echo e($destination->title); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <p>No popular destinations available at the moment.</p>
        <?php endif; ?>






    </div>
</div>

<?php /**PATH C:\Projects\New - Travelbusinessfirst\tbf\resources\views/footernav.blade.php ENDPATH**/ ?>