
<?php $__env->startSection('title', 'Most Popular Flight Destinations'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Popular Flight Destinations</h2>

        <!-- Display success message -->
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <!-- Add new destination button -->
        <div class="mb-3">
            <a href="<?php echo e(route('flight-destination.create')); ?>" class="btn btn-primary">Add New Destination</a>
        </div>

        <!-- Destination table -->
        <table class="table table-bordered">
            <thead>
                <tr>

                    <th>ID</th>
                    <th>region</th>
                    <th>title</th>
                    <th>Image</th>
                    <th>First Class Price</th>
                    <th>Business Class Price</th>
                    <th>Pre Economy Class Price</th>
                    <th>Economy Class Price</th>
                    <th>status</th>
                    <th>user name</th>

                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $destinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($destination->id); ?></td>
                        <td><?php echo e($destination->region); ?></td>
                        <td><?php echo e($destination->title); ?></td>
                        <td><img src="<?php echo e(asset('uploads/' . $destination->title . '/' . $destination->image)); ?>"
                                alt="<?php echo e($destination->title); ?>" class="img-fluid" style="max-width: 100%; height: auto;" />
                        </td>
                        <td><?php echo e($destination->first_class_price); ?></td>
                        <td><?php echo e($destination->business_class_price); ?></td>
                        <td><?php echo e($destination->premier_economy_price); ?></td>
                        <td><?php echo e($destination->economy_price); ?></td>
                        <td><?php echo e($destination->status); ?></td>
                        <td><?php echo e($destination->user ? $destination->user->name : 'N/A'); ?></td>
                        <td>
                            <!-- Edit button -->
                            <a href="<?php echo e(route('flightdestination.edit', $destination->id)); ?>"
                                class="btn btn-sm btn-warning">Edit</a>

                            <!-- Delete button -->
                            <form action="<?php echo e(route('flightdestination.destroy', $destination->id)); ?>" method="POST"
                                style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger"
                                    onclick="return confirm('Are you sure you want to delete this destination?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\New - Travelbusinessfirst\tbf\resources\views/layouts/flightdestinations/index.blade.php ENDPATH**/ ?>