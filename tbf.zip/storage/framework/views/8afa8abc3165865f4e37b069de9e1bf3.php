
<div id="popularCarousel" class="owl-carousel owl-theme">
    <?php if($popularDestinations->isNotEmpty()): ?>
        <?php $__currentLoopData = $popularDestinations->slice(0, 21)->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunkedDestinations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
                <?php $__currentLoopData = $chunkedDestinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card popular-desti-card">
                        <div class="card-img-outer">
                            <img src="<?php echo e(asset('uploads/' . $destination->title . '/' . $destination->image)); ?>"
                                class="img-fluid" alt="<?php echo e($destination->title); ?>">
                            <h2 class="desti-name"><?php echo e($destination->title); ?></h2>
                            <div class="start-from-text"><sup>*</sup>PRICE STARTING FROM</div>
                            <div class="overlay-bottom"></div>
                        </div>
                        <div class="card-body">
                            <div class="row g-1 align-items-center">
                                <div class="col col-md border-end me-2">
                                    <small>FIRST CLASS</small>
                                    <p class="mb-0 fs-18 fw-bold">
                                        £<?php echo e(number_format($destination->first_class_price, 0)); ?>

                                    </p>
                                </div>
                                <div class="col col-md border-end me-2">
                                    <small>BUS. CLASS</small>
                                    <p class="mb-0 fs-18 fw-bold">
                                        £<?php echo e(number_format($destination->business_class_price, 0)); ?></p>
                                </div>
                                <div class="col col-md border-end me-2">
                                    <small>PRE. ECON.</small>
                                    <p class="mb-0 fs-18 fw-bold">
                                        £<?php echo e(number_format($destination->premier_economy_price, 0)); ?></p>
                                </div>
                                <div class="col col-md">
                                    <small>ECONOMY</small>
                                    <p class="mb-0 fs-18 fw-bold">£<?php echo e(number_format($destination->economy_price, 0)); ?>

                                    </p>
                                </div>
                                <div class="col col-md-3 d-inline-flex justify-content-end">
                                    <button
                                        onclick="window.location.href='<?php echo e(url('/flight-city-search/' . $destination->title . '/' . $destination->id)); ?>'"
                                        class="btn btn-view-details mt-2 mt-sm-0">
                                        <span class="d-none d-md-inline-block">View</span> Detail
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>No popular destinations available at the moment.</p>
    <?php endif; ?>

</div>
<?php /**PATH C:\Projects\New - Travelbusinessfirst\tbf\resources\views/layouts/populardestination.blade.php ENDPATH**/ ?>