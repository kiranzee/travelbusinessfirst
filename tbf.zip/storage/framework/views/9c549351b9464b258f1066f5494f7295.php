
<?php $__env->startSection('title', 'Ticket Enquiry'); ?>
<?php $__env->startSection('content'); ?>
    <?php
        use Carbon\Carbon;
    ?>
    <div class="container">
        <h2>Holiday Enquiry</h2>

        <!-- Display success message -->
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>


        <!-- Destination table -->
        <table class="table table-bordered w-100">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Customer Name</th>
                    <th>Customer Email</th>
                    <th>Customer Phone</th>
                    <th>Holiday Date</th>
                    <th>Package Name</th>
                    <th>Package Price</th>
                    <th>Create Date</th>

                </tr>
            </thead>
            <tbody>
                <?php if($holidaydeal->isNotEmpty()): ?>
                    <?php $__currentLoopData = $holidaydeal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($enquiry->id); ?></td>
                            <td><?php echo e($enquiry->customer_name); ?></td>
                            <td><a href="mailto:<?php echo e($enquiry->customer_email); ?>"><?php echo e($enquiry->customer_email); ?></a></td>
                            <td><a href="tel:+44<?php echo e($enquiry->customer_phone); ?>"><?php echo e($enquiry->customer_phone); ?></a></td>
                            <td><?php echo e(Carbon::parse($enquiry->holiday_date)->format('D, d M y')); ?></td>
                            <td><?php echo e($enquiry->bestofactivity->title); ?></td>
                            <td>£<?php echo e($enquiry->bestofactivity->price); ?></td>
                            <td><?php echo e(Carbon::parse($enquiry->created_at)->format('D, d M y')); ?></td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7">
                            <p>No City Flight Enquiries available at the moment.</p>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>




    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\New - Travelbusinessfirst\tbf\resources\views/layouts/customerenquiry/holidaydeal.blade.php ENDPATH**/ ?>