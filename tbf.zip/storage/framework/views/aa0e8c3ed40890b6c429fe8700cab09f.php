<!DOCTYPE html>
<html>

<head>
    <title>Thank You for Your Enquiry</title>
</head>

<body>
    <h2>Thank you, <?php echo e($flightEnquiry->customer_name); ?>!</h2>

    <p>We have received your enquiry for the following Destination(s):</p>

    <?php if($flightEnquiry->flightDetailsEnquiry->isNotEmpty()): ?>
        <table border="1" cellpadding="10" cellspacing="0" style="width: 100%; border-collapse: collapse;">
            <thead>
                <tr>
                    <th>From</th>
                    <th>To</th>
                    <th>Departure Date</th>
                    <th>Return Date</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $flightEnquiry->flightDetailsEnquiry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($detail->from); ?></td>
                        <td><?php echo e($detail->to); ?></td>
                        <td><?php echo e($detail->departure_date); ?></td>
                        <td><?php echo e($detail->return_date); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Thanks for reaching us.</p>
    <?php endif; ?>


    <p>We will get back to you with more details soon.</p>

    <p>Best Regards,<br>Travel Business First Team</p>
</body>

</html>
<?php /**PATH C:\Projects\New - Travelbusinessfirst\tbf\resources\views/emails/thankyou.blade.php ENDPATH**/ ?>