<div id="partnerCarousel" class="owl-carousel owl-theme">
    <div class="item"><img class="img-fluid" src="img/partners/delta.png" alt="">
    </div>
    <div class="item"><img class="img-fluid" src="img/partners/cathey-pacific.png" alt=""></div>
    <div class="item"><img class="img-fluid" src="img/partners/british-airway.png" alt=""></div>
    <div class="item"><img class="img-fluid" src="img/partners/american-airline.png" alt=""></div>
    <div class="item"><img class="img-fluid" src="img/partners/emirets.png" alt="">
    </div>
    <div class="item"><img class="img-fluid" src="img/partners/etihad.png" alt="">
    </div>
    <div class="item"><img class="img-fluid" src="img/partners/united-airlines.png" alt=""></div>
    <div class="item"><img class="img-fluid" src="img/partners/virgin-atlantic.png" alt=""></div>
</div>
